

from core import Decoder, MultiDecoder, NdQueue


def read_file_as_hex_strings(file_path):
    hexs = []
    with open(file_path, 'r') as file:
        for line in file:
            # 去掉每行的换行符
            line = line.strip()
            # 将每3个字符分组，并转换为带空格的hex字符串
            hex_lines = [line[i:i + 3] for i in range(0, len(line), 3)]
            hexss = []
            for h in hex_lines:
                h = h.strip()
                # print(h)
                b = int(h, 16)
                hexss.append(b)
            hexs.append(hexss)
    return hexs


if __name__ == '__main__':
    # 示例：读取文件并打印每行的带空格的hex字符串
    file_path = "D:\\workspace\\NeuroDance\\neuro_dancer_py\\neuro_dance\\rawData.txt"
    hex_strings = read_file_as_hex_strings(file_path)
    queue = NdQueue()
    decoder = Decoder()
    for hex_string in hex_strings:
        for h in hex_string:
            queue.en_queue(h)
        decoder.decode(queue)
